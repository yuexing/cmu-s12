package msg.lab0.amixyue;
import java.io.ObjectInputStream;
import java.net.Socket;

/**
 * Handle the work after connected to the host.
 * Task: get the Message and store them after checking the receive rules.
 * @author yijia
 * @version 1.0
 */
public class ReceiveHandler implements Runnable{
	
	private Socket client;
	
	public ReceiveHandler(Socket c){
		this.client = c;
	}
	
	public void run(){
		try{
			ObjectInputStream ois = new ObjectInputStream(client.getInputStream());
			Message msg = (Message)ois.readObject();
			MessagePasser.getInstance().receive(msg);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
