package msg.lab0.amixyue;

/**
 * A representation of predefined actions.
 * 
 * @author amy
 * @version 1.0
 *
 */
public enum Action {
	drop, delay, duplicate, none
}
