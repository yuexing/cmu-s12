package msg.lab0.amixyue;

import java.net.DatagramPacket;

import org.apache.log4j.Logger;

import util.lab0.amixyue.ObjnByte;

/**
 * Handle the task after UDP connection with host
 * @author yijia
 * @version 1.0
 */
public class UDPReceiveHandler implements Runnable{
	private static Logger logger = Logger.getLogger(UDPReceiveHandler.class);
	private DatagramPacket receivePacket;
	
	public UDPReceiveHandler(DatagramPacket pack){
		this.receivePacket = pack;
	}
	
	public void run(){
		Message msg = (Message)ObjnByte.toObject(receivePacket.getData());
		logger.debug(msg);
		MessagePasser.getInstance().receive(msg);		
	}

}
