package msg.lab0.amixyue;

import org.apache.log4j.Logger;

/**
 * A representation of rules which will be checked by 
 * {@link MessagePasser} before sending and receiving.
 * 
 * @author amy
 * @version 1.0
 */
public class Rule {
	static Logger logger = Logger.getLogger(Rule.class);
	private String src;
	private String dest;
	private String kind;
	private Action action;
	private Integer nth;
	private Integer id;
	
	public Rule(String src, String dest, String kind, String action, Integer id, Integer nth) {
		super();
		this.src = src;
		this.dest = dest;
		this.kind = kind;
		if("drop".equals(action))
			this.action = Action.drop;
		else if("delay".equals(action))
			this.action = Action.delay;
		else if("duplicate".equals(action))
			this.action = Action.duplicate;
		else
			this.action = null;
		this.nth = nth;
		this.id = id;
		logger.debug(this.toString());
	}
	
	public Action check(Message msg){
		if((this.src == null || (this.src!=null&&this.src.equals(msg.getSrc())))
				&&(this.dest == null || (this.dest!=null&&this.dest.equals(msg.getDest())))
				&&(this.kind == null || (this.kind!=null&&this.kind.equals(msg.getKind())))
				&&(this.id == null || (this.id!=null&&this.id.equals(msg.getId())))
				&&(this.nth == null || (this.nth!=null&&this.nth!=0&&msg.getId()%this.nth==0))){
			return this.action;
		}
		return Action.none;
	}
	/**
	 * construct a yaml string for the Node object 
	 * @return yaml string
	 */
	public String configStr(){
		return "\n- Action : "+ this.action.name()
		+ (this.src != null? "\n  Src : " + this.src :"")
		+ (this.dest != null? "\n  Dest : " + this.dest :"")
		+ (this.kind != null? "\n  Kind : " + this.kind :"")
		+ (this.id != null? "\n  ID : " + this.id :"")
		+ (this.nth != null? "\n  Nth : " + this.nth:"");
	}
	@Override
	public String toString() {		
		return this.src + ", " + this.dest 
		+ ", " + this.action 
		+ ", " + this.kind
		+ ", " + this.id
		+ ", " + this.nth;
	}
}
