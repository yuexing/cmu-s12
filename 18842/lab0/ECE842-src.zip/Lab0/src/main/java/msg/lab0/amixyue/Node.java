package msg.lab0.amixyue;

import org.apache.log4j.Logger;

/**
 * A representation of an endpoint for communication between machines.
 * <p>
 * In case the {@link MessagePasser} object can not init, send, receive
 * a {@link Message} object properly, all the fields of a Node object should
 * be set and not null. Or application will exit with code 2 which means local 
 * error.
 * 
 * @author amy
 * @version 1.0
 */
public class Node {
	static Logger logger = Logger.getLogger(Node.class);
	private String nName;
	private String nIP;
	private Integer nPort;
	private String nProtocal;
	
	public Node(String nName, String nIP, Integer nPort, String nProtocal){
		this.nName = nName;
		this.nIP = nIP;
		this.nPort = nPort;
		this.nProtocal = nProtocal;
		logger.debug(this.toString());
		if(this.nName==null||this.nIP==null||this.nPort==null||this.nProtocal==null){
			logger.fatal("Node init with null value");
			System.exit(2);
		}
	}
	
	public String getnName() {
		return nName;
	}
	public void setnName(String nName) {
		this.nName = nName;
	}
	public String getnIP() {
		return nIP;
	}
	public void setnIP(String nIp) {
		this.nIP = nIp;
	}
	public int getnPort() {
		return nPort;
	}
	public void setnPort(int nPort) {
		this.nPort = nPort;
	}
	public String getnProtocal() {
		return nProtocal;
	}
	public void setnProtocal(String nProtocal) {
		this.nProtocal = nProtocal;
	}
	/**
	 * construct a yaml string for the Node object 
	 * @return yaml string
	 */
	public String configStr(){
		return "\n- Name : " + this.nName
		+ "\n  IP : " + this.nIP
		+ "\n  Port : " + this.nPort
		+ "\n  Protocol : " + this.nProtocal;
	}
	@Override
	public String toString() {		
		return this.nName + ", " + this.nIP + ", " 
		+ this.nPort + ", " + this.nProtocal;
	}
}
