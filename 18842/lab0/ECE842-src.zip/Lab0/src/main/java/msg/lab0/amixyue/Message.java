package msg.lab0.amixyue;

import java.io.Serializable;

import org.apache.log4j.Logger;

import util.lab0.amixyue.ObjnByte;

/**
 * A representation of a Message object that will be received and sent 
 * by a {@link MessagePasser} object.
 * <p>
 * In case the {@link MessagePasser} object can not send, receive
 * a {@link Message} object properly, all the fields of a Message object 
 * should be set and not null.
 * <p>
 * A message with a null data is nonsense.
 * <p>
 * Although there's no worry about segmentation which will be 
 * done by network part of Operating System, we should care 
 * about the largest payload of a DatagramPacket which will be 
 * used by UDP protocal and the size is 65507 bytes.
 * For safety, we will set 65000 as a restriction of data.
 * <p>
 * Any one of the above restriction fails, the Message can not be
 * initialized, which should be handled in advance by {@link MessagePasser}.
 * 
 * @author amy
 * @version 1.0
 */
public class Message implements Serializable{
	
	private static final long serialVersionUID = 1054170807765435042L;
	static Logger logger = Logger.getLogger(Message.class);
	private String src;
	private String dest;
	private String kind;
	private Object data;
	private int id;
	
	private static int ID = 0;
	/**
	 * Constructor
	 * @param src
	 * @param dest
	 * @param kind
	 * @param data should not exceed 65000
	 */
	public Message(String src, String dest, String kind, Object data){
		
		this.src = src;
		this.dest = dest;
		this.kind = kind;
		this.data = data;
		if(this.src==null||this.dest==null
				||this.kind==null||this.data==null){
			logger.fatal("Message init with null value");
		}
		if(ObjnByte.toByteArray(this.data).length > 65000){
			logger.fatal("Message init with too large size");
		}
	}
	
	/**
	 * before a {@link MessagePasser} sends a Message, it will set 
	 * the Id of the Message. 
	 * <p>
	 *  IDs should be non-reused, monotonically increasing integer
	 *  values. Each Message in your entire system will have a unique
	 *  combination of source/ID.
	 * 
	 */
	public void setId(){
		this.id = ID++;
	}
	
	public int getId(){
		return this.id;
	}
	public String getSrc() {
		return src;
	}

	public void setSrc(String src) {
		this.src = src;
	}

	public String getDest() {
		return dest;
	}

	public void setDest(String dest) {
		this.dest = dest;
	}

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	@Override
	public String toString() {
		
		return this.id + ": " + this.src + " to " + this.dest + " as " 
		+ this.kind + " with " + this.data;
	}	
}
