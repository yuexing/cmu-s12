package msg.lab1.amixyue;

import msg.lab0.amixyue.*;
import java.util.*;

public class VectorTimeStampedMessage extends Message 
implements Comparable<VectorTimeStampedMessage>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Vector<TimeStamp> vectorTimeStamp;
	
	public VectorTimeStampedMessage(String src, String dest, String kind,
			Object data) {
		super(src, dest, kind, data);
	}

	public Vector<TimeStamp> getVectorTimeStamp() {
		return vectorTimeStamp;
	}

	public void setVectorTimeStamp(Vector<TimeStamp> vectorTimeStamp) {
		this.vectorTimeStamp = vectorTimeStamp;
	}
	
	@Override
	public String toString() {
		String str = super.toString();
		for (TimeStamp t : vectorTimeStamp){
			str += " " + t.toString();
		}
		return str;
	}
	
	public int compareTo(VectorTimeStampedMessage o){
		int sign = 0;
		for(int i=0; i<vectorTimeStamp.size(); i++){
			if(sign ==0){
				if((vectorTimeStamp.get(i).compareTo(o.getVectorTimeStamp().get(i))<0)){
					sign = -1;
				}else if(vectorTimeStamp.get(i)
						.compareTo(o.getVectorTimeStamp().get(i))>0){
					sign = 1 ;
				}
			}else if (sign==-1 && vectorTimeStamp.get(i)
					.compareTo(o.getVectorTimeStamp().get(i))>0){
				sign =0;
				break;
			}else if(sign==1 && vectorTimeStamp.get(i)
					.compareTo(o.getVectorTimeStamp().get(i))<0 ){
				sign = 0;
				break;
			}
		}
		return sign;
	}

}
