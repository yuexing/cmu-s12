package msg.lab1.amixyue;

import msg.lab0.amixyue.Message;

/**
 * ClockService maintain and update system timestamp
 * ,implemented by {@link VectorClockService} and {@link LogicClockService}
 * ,both of which are singleton. 
 * <p>
 * ClockService is produced by {@link ClockServiceFactory}. 
 * @author amy
 *
 */
public interface ClockService {

	/**
	 * any event call call this method to update 
	 * system timestamp
	 */
	void setTimeStamp();
	/**
	 * when send, add a timestamp to tm
	 * when receive, update system timestamp according to rules
	 * when send, {@link TimeStampedMessage.getTimeStamp} return null
	 * when receive, {@link TimeStampedMessage.getTimeStamp} return {@link TimeStamp}
	 * @param tm
	 */
	void setTimeStamp(Message tm);
}
