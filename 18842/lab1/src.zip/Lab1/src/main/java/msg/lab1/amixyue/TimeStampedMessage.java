package msg.lab1.amixyue;

import msg.lab0.amixyue.Message;

public class TimeStampedMessage extends Message implements Comparable<TimeStampedMessage>{

	private TimeStamp timeStamp;
	
	public TimeStampedMessage(String src, String dest, String kind, Object data) {
		super(src, dest, kind, data);
	}

	public TimeStamp getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(TimeStamp timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	@Override
	public String toString() {
		return super.toString()+" " + timeStamp;
	}

	public int compareTo(TimeStampedMessage o){
		return timeStamp.compareTo(((TimeStampedMessage)o).getTimeStamp());
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
