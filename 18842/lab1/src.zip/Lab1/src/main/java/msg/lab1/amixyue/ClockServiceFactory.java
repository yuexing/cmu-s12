package msg.lab1.amixyue;

import java.util.Vector;

import org.apache.log4j.Logger;

import msg.lab0.amixyue.Message;
import msg.lab0.amixyue.MessagePasser;

/**
 * A representation of a factory that produce and maintain 
 * {@link ClockService} for the process.
 * <p>
 * ClockServiceFactory should vaunt there exist only one {@link ClockService}
 * within the process, which means implementation of {@link ClockService} should
 * be its inner private class.
 * @author amy
 *
 */
public class ClockServiceFactory {

	public static final int VectorClock = 1;
	public static final int LogicalClock = 2;
	private static int type;
	private static ClockService instance;
	private static Logger logger = Logger.getLogger(ClockServiceFactory.class);
	
	public synchronized static ClockService getClockService(int type, boolean reinit){
		if(reinit) instance = null;
		if(instance == null || ClockServiceFactory.type != type){
			ClockServiceFactory.type = type;
			switch(type){
			case VectorClock:
				instance = new VectorClockService();
				logger.debug("Process with VectorClock");
				break;
			case LogicalClock:
				instance = new LogicClockService();
				logger.debug("Process with LogicalClock");
				break;
			default:
				instance = null;
			}
		}
		return instance;
	} 
	
	public synchronized static ClockService getClockService(){
		return instance;
	}
	
	public static void init(int n, int meIndex){
		if(type == ClockServiceFactory.VectorClock){
			((VectorClockService)instance).init(n, meIndex);
		}
	}
	/**
	 * 
	 * @author amy
	 *
	 */
	private static class LogicClockService implements ClockService {
		
		private TimeStamp lastTimeStamp;
		
		public LogicClockService(){
			lastTimeStamp = new TimeStamp();
		}
		/* (non-Javadoc)
		 * @see msg.lab1.amixyue.ClockService#setTimeStamp()
		 */
		public void setTimeStamp() {
			lastTimeStamp.add();
		}

		/* (non-Javadoc)
		 * @see msg.lab1.amixyue.ClockService#setTimeStamp(msg.lab1.amixyue.TimeStampedMessage)
		 */
		public void setTimeStamp(Message tm) {
			if(null == ((TimeStampedMessage)tm).getTimeStamp()){
				//send
				lastTimeStamp.add();
				((TimeStampedMessage)tm).setTimeStamp(lastTimeStamp);
			}else{
				
				//receive
				if(lastTimeStamp.compareTo(((TimeStampedMessage)tm).getTimeStamp())<0)
					lastTimeStamp = ((TimeStampedMessage)tm).getTimeStamp().add();
				else 
					lastTimeStamp.add();
				//update tm later
				((TimeStampedMessage)tm).setTimeStamp(lastTimeStamp);
			}
		}
	}
	/**
	 * assume system contains n process
	 * each process Pi has a clock Ci(Singleton), which is an integer vector of length n
	 * <p>
	 * Ci[i] is Pi's logical time
	 * <p>
	 * Ci[k] is Pi's guess of the logical time at Pk
	 * <p>
	 * Ci[i](a) is for Pi's any event a
	 * <p>
	 * Ci[i] is the number of events that Pi has timestamped, and Ci[k] is the 
	 * number of events that have occurred at Pk that Pi has potentially been affected by
	 * @author amy
	 *
	 */
	private static class VectorClockService implements ClockService {
		private Vector<TimeStamp> vector;
		private int meIndex;
		
		VectorClockService(){		
		}
		
		public void init(int n, int meIndex){
			this.vector = new Vector<TimeStamp>(n);
			this.meIndex = meIndex;
			for(int i =0; i<n; i++){
				vector.add(new TimeStamp());
			}
		}
		
		/* (non-Javadoc)
		 * @see msg.lab1.amixyue.ClockService#setTimeStamp()
		 */
		public void setTimeStamp() {
			//update time
			vector.get(meIndex).add();
		}

		/* (non-Javadoc)
		 * @see msg.lab1.amixyue.ClockService#setTimeStamp(msg.lab1.amixyue.TimeStampedMessage)
		 */
		public void setTimeStamp(Message tm) {
			if(null == ((VectorTimeStampedMessage)tm).getVectorTimeStamp()){
				//send just update myself
				vector.get(meIndex).add();
				((VectorTimeStampedMessage)tm).setVectorTimeStamp(vector);
				//don't consider dest
			}else{
				//receive
				vector.get(meIndex).add();
				//set Message
				//((VectorTimeStampedMessage)tm).setVectorTimeStamp(vector);
				//src
				int srcIndex = MessagePasser.getInstance().getIndex(tm);
				
				if(vector.get(srcIndex).compareTo(((VectorTimeStampedMessage)tm).getVectorTimeStamp().get(srcIndex))<0){
					//usually d=0 unlesss needed to model network delay
					logger.debug("setting: "+vector.get(srcIndex));
					vector.set(srcIndex, ((VectorTimeStampedMessage)tm).getVectorTimeStamp().get(srcIndex));
				}else{
					vector.get(srcIndex).add();
				}
				((VectorTimeStampedMessage)tm).setVectorTimeStamp(vector);
			}
		}
		
		
	}
}
