package msg.lab1.amixyue;

import java.io.Serializable;

/**
 * A representation of time stamp which is maintained and 
 * updated by {@link ClockService}
 * <p>
 * self process time stamp should be singleton and increase monotonically
 * which should be vaunted by {@link ClockService}
 * <p>
 * @author amy
 *
 */
public class TimeStamp implements Serializable{

	//private static int Time = -1;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int time;
	
	public TimeStamp(){
		this.time = 0;
	}
	
	/**
	 * used to update other processes' time
	 * @return
	 */
	public TimeStamp add(){
		this.time++;
		return this;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(this.time == ((TimeStamp)obj).time)
		return true;
		else return false;
	}
	
	public int compareTo(Object obj){
		if(this.equals(obj))
			return 0;
		else{
			if(this.time > ((TimeStamp)obj).time)
				return 1;
			else 
				return -1;
		}
	}	

	@Override
	public String toString() {
		return String.valueOf(time);
	}
	
}
