package msg.lab1.amixyue;

import java.io.*;

import org.apache.log4j.*;

import util.lab.amixyue.FileScheduler;
import util.lab.amixyue.TimeStep;
import msg.lab0.amixyue.*;
/**
 * Proxy of {@link MessagePasser}, do send and receive for {@link MessagePasser}. 
 * @author amy
 *
 */
public class MessagePasserProxy {

	private static Logger logger = Logger.getLogger(MessagePasserProxy.class);
	private MessagePasser messagePasser;
	private ClockService clockService;
	private int type;
	private String config;
	private final String loggerName = "Logger";
	private final String loggerType = "Log";
	
	public MessagePasserProxy(String config, String localName){
		this.config = config;
		this.messagePasser = MessagePasser.getInstance(config, localName);
		this.type = messagePasser.getType();
		logger.debug("parse clock service type: "+this.type);
		clockService = ClockServiceFactory.getClockService(type,false);
		//init vector service
		ClockServiceFactory.init(messagePasser.getNodeCount()
					, messagePasser.getMeIndex());
		this.startChkConfigFile();
	}
	
	public int getType(){
		return type;
	}
	
	public void startChkConfigFile(){
		FileScheduler schedule = new FileScheduler();
		schedule.schedule(new Runnable(){
			private boolean isFirst = true;
			private long current;
			
			public void run() {
				File f = new File(MessagePasserProxy.this.config);
				if(isFirst){
					isFirst = false;
					loadFileInfo(f);
				}else{
					checkFileUpdate(f);
				}				
			}
			private void loadFileInfo(File f){
				current = f.lastModified();
			}
			
			private void checkFileUpdate(File f){
				if(current != f.lastModified()){
					//updated
					current = f.lastModified();
					logger.debug("Config File Changed");
					MessagePasser.getInstance().Init();
					MessagePasserProxy.this.type = messagePasser.getType();
					logger.debug("parse clock service type: "+MessagePasserProxy.this.type);
					MessagePasserProxy.this.clockService = ClockServiceFactory.getClockService(type,true);
					//init vector service
					ClockServiceFactory.init(messagePasser.getNodeCount()
								, messagePasser.getMeIndex());
				}
			}
			
		}, new TimeStep());
	}
	
	/**
	 * add timestamp to message and then send
	 * @param m
	 */
	public void send(Message m){
		clockService.setTimeStamp(m);
		logger.debug("send before setId: " + m);
		messagePasser.send(m);
		
		String content = "#Send# " + (String)m.getData();
		m.setData(content);
		
		Message log = new Message(messagePasser.getName(), this.loggerName, 
				this.loggerType, m);
		messagePasser.send(log);
	}
	
	/**
	 * update system timestamp only when user will receive
	 * @return
	 */
	public Message receive(){
		Message msg = messagePasser.receive();
		if (msg != null) {
			logger.debug("receive: "+msg);
			clockService.setTimeStamp(msg);
			
			String content = "#Receive# " + (String)msg.getData();
			msg.setData(content);
			
			Message log = new Message(messagePasser.getName(), this.loggerName, 
					this.loggerType, msg);
			messagePasser.send(log);
		}		
		else 
			logger.debug("No messages in the buffer");
		return msg;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MessagePasserProxy proxy = new MessagePasserProxy(
				"D://lab0.config", 
				"B");
		MessagePasser passer = MessagePasser.getInstance();
		BufferedReader wt = new BufferedReader(new InputStreamReader(System.in));
		while (true){
			try {
				System.out.println("Please Enter the Command: ");
				String command = wt.readLine();
				if (command.equals("end")) break;
				//command 1: sendto [name] [kind] [content]
				//command 2: receive
				if (command.equals("receive")){
					@SuppressWarnings("unused")
					Message msg = proxy.receive();
					//process msg
				}else{
					if (!command.startsWith("sendto")){
						logger.error("Error Command");
						continue;
					}else{
						String[] vars = command.split("\\s+");
						if (vars.length != 4){
							logger.error("Error Command");
							continue;
						}else{
							Message msg = null;
							if(proxy.getType()==ClockServiceFactory.LogicalClock)
								msg = new TimeStampedMessage(passer.getName(), vars[1], vars[2], vars[3]);
							else 
								msg = new VectorTimeStampedMessage(passer.getName(), vars[1], vars[2], vars[3]);
							proxy.send(msg);
						}
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}		
		}
		passer.exit(0);
	}
}
