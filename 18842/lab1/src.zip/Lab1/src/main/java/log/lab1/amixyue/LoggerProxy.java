package log.lab1.amixyue;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.Comparator;

import org.apache.log4j.Logger;

import util.lab.amixyue.FileScheduler;
import util.lab.amixyue.TimeStep;

import msg.lab0.amixyue.*;
import msg.lab1.amixyue.*;

/**
 * A representation of Logger, who just need to receive {@link Message}
 * and order {@link Message} according to current clock service type when user asks.
 * <p>
 * Once the config file changes, it need to reinit {@link MessagePasser}, which include 
 * reinit nodes, rules and receive message array, in addition, restart receive service. 
 * And the message array is used for view.
 * @author amy
 *
 */
public class LoggerProxy {

	private static Logger logger = Logger.getLogger(Logger.class);
	private static String config;
	private static String name;
	private static MessagePasser messagePasser;
	
	static {
		config= "D:\\lab0.config";
		name= "log";
		messagePasser= MessagePasser.getInstance(
			config, name);
		startChkConfigFile();
	}
	
	private static void startChkConfigFile(){
		FileScheduler schedule = new FileScheduler();
		schedule.schedule(new Runnable(){
			private boolean isFirst = true;
			private long current;
			
			public void run() {
				File f = new File(LoggerProxy.config);
				if(isFirst){
					isFirst = false;
					loadFileInfo(f);
				}else{
					checkFileUpdate(f);
				}				
			}
			private void loadFileInfo(File f){
				current = f.lastModified();
			}
			
			private void checkFileUpdate(File f){
				if(current != f.lastModified()){
					//updated
					current = f.lastModified();
					logger.debug("Config File Changed");
					MessagePasser.getInstance().Init();
					logger.debug("parse clock service type: "+messagePasser.getType());
					ClockServiceFactory.getClockService(messagePasser.getType(),true);
					//init vector service
					ClockServiceFactory.init(messagePasser.getNodeCount()
								, messagePasser.getMeIndex());
				}
			}
			
		}, new TimeStep());
	}
	/**
	 * @param args
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) {
		BufferedReader wt = new BufferedReader(new InputStreamReader(System.in));
		while (true){
			try {
				System.out.println("Enter View to show logger: ");
				String command = wt.readLine();
				if (command.equals("end")) break;
				//command 1: sendto [name] [kind] [content]
				//command 2: receive
				if (command.equals("view")){
					if(messagePasser.getType()==ClockServiceFactory.LogicalClock){
						Collections.sort(messagePasser.getRecvArray(),new Comparator(){
							public int compare(Object o0, Object o1) {
								TimeStampedMessage m1 = (TimeStampedMessage)((Message)o0).getData();
								TimeStampedMessage m2 = (TimeStampedMessage)((Message)o1).getData();
								return m1.compareTo(m2);
							}						
						});
						for(Message m : messagePasser.getRecvArray()){
							logger.info((TimeStampedMessage)m.getData());
						}
					}else if(messagePasser.getType()==ClockServiceFactory.VectorClock){
						Collections.sort(messagePasser.getRecvArray(), new Comparator(){
							public int compare(Object o1, Object o2) {
								VectorTimeStampedMessage m1 = (VectorTimeStampedMessage)((Message)o1).getData();
								VectorTimeStampedMessage m2 = (VectorTimeStampedMessage)((Message)o2).getData();
								return m1.compareTo(m2);
							}							
						});
						for(Message m : messagePasser.getRecvArray()){
							logger.info((VectorTimeStampedMessage)m.getData());
						}
					}					
					
				}else{
					logger.error("error msg!");
				}
			} catch (IOException e) {
				e.printStackTrace();
			}		
		}
		messagePasser.exit(0);

	}

}
