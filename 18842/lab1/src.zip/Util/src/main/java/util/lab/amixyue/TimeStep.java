package util.lab.amixyue;

import java.util.*;
/**
 * TimeStep returns a time which is based on the time when it first 
 * initialized and changed according to its unit and period, thus is 
 * used by File Scheduler.
 * <p>
 * The default unit is second, and the default period is 10, which 
 * indicates the interval is 10 second.
 * 
 * @author amy
 *
 */
public class TimeStep {

	private Calendar calendar = Calendar.getInstance();
	private int unit = Calendar.SECOND;
	private int period = 10;
	
	public TimeStep(){
		
	}
	
	public TimeStep(int period){
		this.period = period;
	}
	
	public TimeStep(int unit, int period){
		this.unit = unit;
		this.period = period;
	}
	
	
	public int getUnit() {
		return unit;
	}

	public void setUnit(int unit) {
		this.unit = unit;
	}

	public int getPeriod() {
		return period;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	
	public Date next(){
		calendar.add(unit, period);
		return calendar.getTime();
	}
}
