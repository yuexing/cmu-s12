package util.lab.amixyue;

import java.io.*;

import org.apache.log4j.Logger;

/**
 * Each FileTask initialized with a file.
 * When a FileTask first runs, it will get the last modified 
 * time of corresponding file, then it just check.
 * <p>
 * If the corresponding file has changed, it will call 
 * {@link MessagePasser} to init again.
 * @author amy
 * @deprecated
 */
public class FileTask implements Runnable {

	private static Logger logger = Logger.getLogger(FileTask.class);
	private boolean isFirst = true;
	
	private String file;
	private long current;
	
	public FileTask(){		
	}
	
	public FileTask(String file){
		this.file = file;
	} 
	
	public void run() {
		File f = new File(file);
		if(isFirst){
			isFirst = false;
			loadFileInfo(f);
		}else{
			checkFileUpdate(f);
		}
	}
	
	private void loadFileInfo(File f){
		current = f.lastModified();
	}
	
	private void checkFileUpdate(File f){
		if(current != f.lastModified()){
			//updated
			current = f.lastModified();
			logger.debug("Config File Changed");
			//MessagePasser.getInstance().Init();
		}
	}

}
