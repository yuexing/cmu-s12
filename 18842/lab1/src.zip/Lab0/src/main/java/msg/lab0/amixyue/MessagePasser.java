package msg.lab0.amixyue;

import java.io.*;
import java.util.*;
import java.net.*;
import org.apache.log4j.Logger;
import org.yaml.snakeyaml.*;

import util.lab.amixyue.FileScheduler;
import util.lab.amixyue.TimeStep;
import util.lab0.amixyue.*;

/**
 * A representation of MessagePasser through which 
 * communication will pass. A sender will call MessagePasser to 
 * send a {@link Message} to other process on other hosts. 
 * A receiver (destination) will also call MessagePasser to 
 * receive messages.
 * <p>
 * The MessagePasser will be instantiated only once in
 * an interactive application using two parameters. The first 
 * one specifies a configuration file using yaml syntax, 
 * while the second one specifies local name to distinguish 
 * this process from any others.
 * <p>
 * The MessagePasser will parse configuration file to model
 * all the {@link Node} and {@link Rule}, and then start receive 
 * thread.
 * <p>
 * Also, the MessagePasser is a monitor of configuration file 
 * which is placed in DFS by starting a checkFile thread. Once
 * the configuration file is changed, the MessagePasser will 
 * init all the {@link Node} and {@link Rule} again, which will
 * block other process such as send and receive.
 * <p>
 * TODO :Port numbers listed in configuration file are for initial 
 * communication, perhaps messages need to go to a different 
 * port?
 * TODO :handle not successful.
 * TODO :The constructor will initialize buffers to hold 
 * incoming and outgoing messages to the rest of the nodes in the system. 
 * Additional state (threads?) may be required as well.
 * TODO :demonstrate
 * 
 * @author amy, yijia
 *
 */
public class MessagePasser {
	private static MessagePasser instance;
	private static Logger logger = Logger.getLogger(MessagePasser.class);
	
	private final int MAX_PACK_SIZE = 65000;
	private static final int TIMEOUTMS = 5000;
	
	private ArrayList<Node> nodes = new ArrayList<Node>();
	private ArrayList<Rule> sendRules = new ArrayList<Rule>();
	private ArrayList<Rule> receiveRules = new ArrayList<Rule>();
	private ArrayList<Message> recvArray = new ArrayList<Message>();
	
	private Queue<Message> recvQueue = new LinkedList<Message>();
	private Queue<Message> delayQueue = new LinkedList<Message>();
	private Queue<Message> sendQueue = new LinkedList<Message>();
	
	private String localName ;
	private String configFile;
	private String Protocal;
	private int port;
	private Thread receiveThread;
	//for vector clock service
	private int meIndex;
	//clock service
	private int type;
	
	/**
	 * Constructor
	 * <p>
	 * calls init to read configFile to initialize 
	 * <p>
	 * nodes, a list of {@link Node}
	 * <p>
	 * sendRules, a list of {@link Rule}
	 * <p>
	 * receiveRules, a list of {@link Rule}
	 * <p>
	 * and start receive thread.
	 * <p>
	 * The process may involve in updating the configFile.
	 *  
	 * @param configFile configuation file
	 * @param localName the name of local {@link Node}
	 */
	private MessagePasser(String configFile, String localName){
		this.localName = localName;
		this.configFile = configFile;
		this.port = 0;
		this.Protocal = "";
		this.Init();	
		//ask to start for proxy need different chk
		//this.startChkConfigFile();
		logger.debug(this.toString());
	}
	
	/**
	 * Singleton Creator
	 * @param configuration_filename
	 * @param local_name
	 */
	public static synchronized MessagePasser getInstance(String configuration_filename, String local_name){
		if (null == instance){
			instance = new MessagePasser(configuration_filename, local_name);
		}
		return instance;
	}
	
	/**
	 * Get instance of MessagePasser
	 * @return instance
	 */
	public static MessagePasser getInstance(){
		return instance;
	}
	
	public synchronized ArrayList<Message> getRecvArray(){
		return recvArray;
	}
	public int getType(){
		return type;
	}
	/**
	 * checks message according to restrictions and sendRule
	 * puts msg to proper queue and deliver.
	 * @param msg
	 */
	public void send(Message msg) {	
		msg.setId();
		//check msg before send
		if(msg.getSrc()==null||msg.getDest()==null
				||msg.getKind()==null||msg.getData()==null){
			logger.fatal("Message init with null value");
			return;
		}
		if(ObjnByte.toByteArray(msg.getData()).length > 65000){
			logger.fatal("Message init with too large size");
			return;
		}
		//check action before send
		boolean isAction = false;
		for (Rule rule : sendRules) {
			if (isAction) break;
			Action action = rule.check(msg);
			switch (action) {
			case drop:
				logger.debug("#Action before send# " + msg.toString() + " :drop");
				isAction = true;
				break;
			case delay://
				logger.debug("#Action before send# " + msg.toString() + " :delay");
				delayQueue.add(msg);
				logger.debug(delayQueue.size());
				isAction = true;
				break;
			case duplicate:
				logger.debug("#Action before send# " + msg.toString() + " :duplicate");
				sendQueue.add(msg);
				logger.debug(sendQueue.size());
				sendDelay(false);// Send the first normal message
				logger.debug(sendQueue.size());
				// deal with the delay queue
				if (!delayQueue.isEmpty())
					sendDelay(true);

				sendQueue.add(msg);
				logger.debug(sendQueue.size());
				sendDelay(false);
				logger.debug(sendQueue.size());
				isAction = true;
				break;
			default:
				break;
			}
		}
		if (!isAction){
			logger.debug("#Action before send# " + msg.toString() + " :normal");
			sendQueue.add(msg);
			sendDelay(false);
			if (!delayQueue.isEmpty())
				sendDelay(true);
		}
	}
	
	public int getNodeCount(){
		return this.nodes.size();
	}
	public int getMeIndex(){
		return this.meIndex;
	}
	public int getIndex(Message msg){
		int tmpIndex = 0;
		for(Node node: nodes){			
			if(msg.getSrc().equals(node.getnName())){
				//logger.debug(msg.getSrc()+ " : " + tmpIndex);
				return tmpIndex;
			}
			tmpIndex++;
		}
		logger.debug("get index for clock service error!");
		return -1;
	}
	/**
	 * Send {@link Message} to destination using TCP or UDP
	 * , always called by sendDelay 
	 * @param msg
	 */
	private void sendM(Message msg){
		for(Node node :nodes){
			if(msg.getDest().equals(node.getnName())){
				if(node.getnProtocal().equals("TCP")){
					logger.debug("TCP sending...");
					//set dest socket address
					SocketAddress sockAddr = 
						new InetSocketAddress(node.getnIP(), node.getnPort());
					//set unbond socket
					Socket clnSocket = new Socket();
					try {
//						clnSocket.connect(sockAddr, );
						clnSocket.connect(sockAddr, TIMEOUTMS);
					} catch (IOException e) {
						e.printStackTrace();
						logger.fatal("connect to " + node.toString() + " Timeout.");
						logger.fatal("Message: " + msg.toString() + " Failure");
						return;
					}
					//send
					ObjectOutputStream wt = null;
					try {
						wt = new ObjectOutputStream(clnSocket.getOutputStream());
						wt.writeObject(msg);
						wt.flush();
					} catch (IOException e) {
						e.printStackTrace();
						logger.fatal("send to " + node.toString()+ msg.getData() + " Error.");
						return;
					}
					
					try {
						clnSocket.close();
					} catch (IOException e) {
						e.printStackTrace();
						logger.fatal("Close Socket Error");
					}
				}else{
					logger.debug("UDP sending...");
					byte[] buf = ObjnByte.toByteArray(msg);
					if (buf.length > MAX_PACK_SIZE){
						logger.fatal("Message is too big");
						return;
					}
					DatagramSocket clnSocket = null;
					try {
						clnSocket = new DatagramSocket();
						clnSocket.setSoTimeout(TIMEOUTMS);
					} catch (SocketException e1) {
						e1.printStackTrace();
						logger.fatal("UDP Socket Creating Error");
						return;
					}
					//send
					DatagramPacket sendPacket = null;
					try {
						sendPacket = new DatagramPacket(buf, buf.length, 
								InetAddress.getByName(node.getnIP()), node.getnPort());
					} catch (UnknownHostException e) {
						e.printStackTrace();
						logger.fatal("connect to " + node.toString()+" Timeout.");
						return;
					}
					try {
						clnSocket.send(sendPacket);
					} catch (IOException e) {
						e.printStackTrace();
						logger.fatal("send to " + node.toString()+ msg.getData() + " Error.");
						return;
					}
					
					clnSocket.close();
				}					
			}
		}
	}
	
	/**
	 * Deal with Message From the message queue and deday queue
	 * @param delay
	 * if delay == true, send all the messages in the delay queue
	 * else delay == false, send one message in the send queue
	 */
	private void sendDelay(boolean delay){
		if (delay == false){
			Message msg = sendQueue.peek();
			if (msg != null) {
				sendQueue.remove();
				sendM(msg);
			}
		}else{
			while(!delayQueue.isEmpty()){
				Message msg = delayQueue.peek();
				delayQueue.remove();
				sendM(msg);
			}
		}
	}
	
	/**
	 * deliver {@link Message} from recvQueue
	 * @return {@link Message}
	 */
	public synchronized Message receive(){
		Message msg = recvQueue.peek();
		if(msg != null){
			recvQueue.remove();
			return msg;
		}
		return null;
	}

	/**
	 * receive {@link Message} and process according to receiveRules.
	 * 
	 * @param msg {@link Message}
	 */
	public synchronized void receive(Message msg){
		boolean isAction = false;
		logger.debug("Message Received to the buffer " + msg.toString());
		for (Rule rule : receiveRules) {
			if (isAction) break;
			Action action = rule.check(msg);
			switch (action) {
			case drop:
				logger.debug(msg.toString() + " :drop");
				isAction = true;
				break;
			case duplicate:
				logger.debug(msg.toString() + " :duplicate");
				recvQueue.add(msg);
				recvQueue.add(msg);
				recvArray.add(msg);
				recvArray.add(msg);
				isAction = true;
				break;
			default:
				break;
			}
		}
		if (!isAction) {
			recvQueue.add(msg);
			recvArray.add(msg);
		}
	}
	/**
	 * parses configFile according to yaml syntax 
	 * to initialize or reinitialize nodes and rules.
	 * <p>
	 * This method block should be synchronized in case
	 * that the send action might use wrong destination 
	 * or sendRule. 
	 * <p>
	 * while parsing, checks local ip and prepare to start 
	 * receive thread later, which may lead to uploading 
	 * configFile.
	 * 
	 * @param configFile
	 */
	public synchronized void Init(){
		//clear
		nodes.clear();
		receiveRules.clear();
		sendRules.clear();
		//for proxy
		recvArray.clear();
		
		Yaml yaml = new Yaml();
		Iterable<Object> objs = null;
		/*
		 * URL url = null;
		 * HttpURLConnection conn = null;
		 * InputStream yamlin = null;
		 */	
		/*
		 *  if my ip is not identical to my ip from configFile
		 *  then switch chgConfig to true and construct chgStr,
		 *  later uploads new configFile.
		 */
		boolean chgConfig = false;
		String chgStr = "";
		//use dropbox instead of FTP
		try {
			objs = yaml.loadAll(new FileInputStream(new File(configFile)));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
			logger.fatal("ConfigFile Get Error");
			this.exit(2);
		}
		//parse configFile get nodes, sendRules, receiveRules
		for(Object obj : objs){
			@SuppressWarnings("unchecked")
			Map<String, ArrayList<Map<String,Object>>> map = (Map<String, ArrayList<Map<String,Object>>>)obj;
			for(String key : map.keySet()){
				ArrayList<Map<String,Object>> objList = map.get(key);
				if(key.equals("ClockService")){
					logger.debug("parse ClockService");
					for(Map<String,Object> objNode: objList){
						type = (Integer)objNode.get("type");
					}
				}else if(key.equals("Configuration")){
					logger.debug("parse Configuration");
					int tmpIndex = 0;
					for(Map<String,Object> objNode: objList){
						
						//check me
						if(this.localName.equals((String)objNode.get("Name"))){
							this.meIndex = tmpIndex;
							try {
								if(!((String)objNode.get("IP"))
										.equals(InetAddress.getLocalHost().getHostAddress())){
									//mark 
									chgConfig = true;
									objNode.put("IP", InetAddress.getLocalHost().getHostAddress());
								}								
							} catch (UnknownHostException e) {
								e.printStackTrace();
								logger.fatal("Local IP Address Get Error");
								this.exit(1);
							} 
						}
						Node tmpNode = new Node(
								(String)objNode.get("Name"),
								(String)objNode.get("IP"), 
								(Integer)objNode.get("Port"),
								objNode.containsKey("Protocal")?
										(String)objNode.get("Protocal"):"TCP");
						nodes.add(tmpNode);
						//prepare to start receive thread
						if (tmpNode.getnName().equals(this.localName)){
							if (!this.Protocal.equals(tmpNode.getnProtocal())
									|| this.port != tmpNode.getnPort()){
								this.Protocal = tmpNode.getnProtocal();
								this.port = tmpNode.getnPort();
								restartReceive();
							}
						}				
						tmpIndex++;	
					}
					//
					if(chgConfig){
						chgStr += "\nClockService :";
						chgStr += "\n- type : "+this.type;
						chgStr += "\nConfiguration :";
						for (Node node : nodes){
							chgStr += node.configStr();
						}
					}
				}else if(key.equals("SendRules")){
					logger.debug("parse SendRules");
					if(chgConfig){
						chgStr += "\nSendRules :";
					}
					for(Map<String,Object> objRule: objList){
						Rule tmpRule = new Rule(
								(String)objRule.get("Src"),
								(String)objRule.get("Dest"),
								(String)objRule.get("Kind"),
								(String)objRule.get("Action"),
								(Integer)objRule.get("ID"),
								(Integer)objRule.get("Nth"));
						//
						if(chgConfig){
							chgStr += tmpRule.configStr();
						}
						sendRules.add(tmpRule);
					}
				}else if(key.equals("ReceiveRules")){
					logger.debug("parse ReceiveRules");
					if(chgConfig){
						chgStr += "\nReceiveRules :";
					}
					
					for(Map<String,Object> objRule: objList){
						Rule tmpRule = new Rule(
								(String)objRule.get("Src"),
								(String)objRule.get("Dest"),
								(String)objRule.get("Kind"),
								(String)objRule.get("Action"),
								(Integer)objRule.get("ID"),
								(Integer)objRule.get("Nth"));
						//
						if(chgConfig){
							chgStr += tmpRule.configStr();
						}
						receiveRules.add(tmpRule);
					}	
					//uploads configFile
					if(chgConfig){
						FileWriter fw = null;
						try {
							fw = new FileWriter(new File(configFile));
							fw.write(chgStr);
							fw.close();
							logger.debug(configFile + " Writed");
						} catch (IOException e) {
							e.printStackTrace();
							logger.fatal(configFile + "Write Error");
						}						
//						try {
//							FTPServer.upload(configFile, new FileInputStream(new File(configFile)));
//							//FTPServer.upload("lab0.config", new FileInputStream(new File("lab0.config")));
//						} catch (FileNotFoundException e) {
//							e.printStackTrace();
//						}
//						FTPServer.close();
					}
					
				}else{
				//what happened
					logger.fatal(key +" Unknown Parse Unit");
				}
			}
		}
	}
	@Override
	public String toString() {
		return "MessagePasser [nodes=" + nodes + ", sendRules=" + sendRules
				+ ", receiveRules=" + receiveRules + ", msgQueue=" + recvQueue
				+ ", localName=" + localName + "]";
	}
	
	/**
	 * Start Receive Service
	 */
	private void startReceive(){
		receiveThread = new Thread(new Receiver(port, Protocal));
		receiveThread.start();
		logger.debug("Receive Service Started!");
	}
	
	/**
	 * Start configfile check
	 */
	public void startChkConfigFile(){
		FileScheduler schedule = new FileScheduler();
		schedule.schedule(new Runnable(){
			private boolean isFirst = true;
			private long current;
			
			public void run() {
				File f = new File(MessagePasser.this.configFile);
				if(isFirst){
					isFirst = false;
					loadFileInfo(f);
				}else{
					checkFileUpdate(f);
				}				
			}
			private void loadFileInfo(File f){
				current = f.lastModified();
			}
			
			private void checkFileUpdate(File f){
				if(current != f.lastModified()){
					//updated
					current = f.lastModified();
					logger.debug("Config File Changed");
					MessagePasser.getInstance().Init();
				}
			}
			
		}, new TimeStep());
	}
	/**
	 * Close Receive Service
	 */
	@SuppressWarnings({ "deprecation" })
	private void closeReceive(){
		if (receiveThread != null) {
			receiveThread.stop();
			logger.debug("Receive Service Stopped!");
		}
	}
	/**
	 * If user change the port, the receive service should be restarted
	 */
	private void restartReceive(){
		closeReceive();
		startReceive();
	}
	/**
	 * get Local Name
	 * @return localName
	 */
	public String getName(){
		return this.localName;
	}
	/**
	 * clean thread and exit program
	 * @param code 
	 * 1: Local Network Error
	 * 2: Remote Network Error
	 */
	public void exit(int code){
		//not daemon, no need, will exit as program exit.
		closeReceive();
		System.exit(code);
	}
	//test 
	public static void main(String[] args){
		
		MessagePasser passer = MessagePasser.getInstance("D:\\lab0.config", 
				"charlie");
		passer.startChkConfigFile();
		logger.debug(passer.getName() + " " + passer.port);
		BufferedReader wt = new BufferedReader(new InputStreamReader(System.in));
		while (true){
			try {
				logger.debug(InetAddress.getLocalHost().getHostAddress());
				System.out.println("Please Enter the Command: ");
				String command = wt.readLine();
				if (command.equals("end")) break;
				//command 1: sendto [name] [kind] [content]
				//command 2: receive
				if (command.equals("receive")){
					Message msg = passer.receive();
					if (msg != null) MessagePasser.logger.debug(msg.toString());
					else MessagePasser.logger.debug("No messages in the buffer");
				}else{
					if (!command.startsWith("sendto")){
						logger.error("Error Command");
						continue;
					}else{
						String[] vars = command.split("\\s+");
						if (vars.length != 4){
							logger.error("Error Command");
							continue;
						}else{
							Message msg = new Message(passer.getName(), vars[1], vars[2], vars[3]);			
							passer.send(msg);
							//TODO: send to logger
						}
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}		
		}
		passer.exit(0);
	}
	
}
