package msg.lab0.amixyue;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.SocketException;

import org.apache.log4j.Logger;

/**
 * A Listener works as a server to accept all the connection to the host.
 * <p>
 * If the connection is TCP, create a new thread {@link ReceiveHandler} to Handle.
 * If the connection is UDP, create a new thread {@link UDPReceiveHandler} to Handle.
 * @author yijia
 * @version 1.0
 */
public class Receiver implements Runnable {

	static Logger logger = Logger.getLogger(Receiver.class);
	private int port;
	private String Protocal;

	public Receiver(int port, String Protocal) {
		this.port = port;
		this.Protocal = Protocal;
	}

	public void run() {
		if (Protocal.equals("TCP")) {
			try {
				ServerSocket server = new ServerSocket(port);
				while (true) {
					Thread rhThead = new Thread(new ReceiveHandler(
							server.accept()));
					rhThead.start();
				}
			} catch (IOException e) {
				e.printStackTrace();
				logger.fatal("Create Socket Error");
			}
		} else {
			try {
				DatagramSocket serverSocket = new DatagramSocket(port);
				byte[] receiveData = new byte[65000];
				while (true) {
					logger.debug("init UDP packet");
					DatagramPacket receivePacket = new DatagramPacket(
							receiveData, receiveData.length);
					try {
						logger.debug("before UDP receive");
						serverSocket.receive(receivePacket);
						logger.debug("UDP receive");
					} catch (IOException e) {
						e.printStackTrace();
						logger.fatal("UDP Message Receive Error");
					}
					Thread rhThead = new Thread(new UDPReceiveHandler(receivePacket));
					rhThead.start();
				}
			} catch (SocketException e) {
				e.printStackTrace();
				logger.fatal("Create Socket Error");
			}
		}
	}

}
