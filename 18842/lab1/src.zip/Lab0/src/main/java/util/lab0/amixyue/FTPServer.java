package util.lab0.amixyue;

import java.io.*;
import java.net.SocketException;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.log4j.Logger;

/**
 * A representation of a FTP Server, including setup, upload, download
 * <p>
 * It can be very useful to have the configuration file live on a 
 * distributed filesystem (like AFS or dropbox) so each node can read 
 * copies without needing to FTP them around
 * @author amy
 * @deprecated
 */
public class FTPServer {
	private static Logger logger = Logger.getLogger(FTPServer.class);
	private static String host = "amixyue.comlu.com";
	private static String uname = "a4004782";
	private static String upwd = "cmuece842";
	private static FTPClient ftp;
	
	public static void setup(){
		ftp = new FTPClient();
		
		try {
			ftp.connect(host);
			ftp.login(uname, upwd);
			ftp.changeWorkingDirectory("/public_html");
			ftp.setFileType(FTP.BINARY_FILE_TYPE);	
			ftp.setControlKeepAliveTimeout(300);
//			reply = ftp.getReplyCode();
//			if(FTPReply.isPositiveCompletion(reply)){
//				ftp.disconnect();
//				logger.fatal("FTP Connect Error");
//				System.exit(1);
//			}
			logger.debug("FTP connected");
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	public static void upload(String fname, 
			InputStream in){
		try {
			ftp.storeFile(fname, in);
			logger.debug(ftp.getReplyString());
		} catch (IOException e) {
			e.printStackTrace();
			logger.debug(fname +" store error");
			System.exit(1);
		}
		logger.debug(fname + " Stored.");
	}
	
	public static InputStream download(String fname){		
		InputStream in = null;
		try {
			in = ftp.retrieveFileStream(fname);
		} catch (IOException e) {
			e.printStackTrace();
			logger.debug(fname +" Retrive error");
			System.exit(1);
		}
		logger.debug(fname + " Retrived.");
		return in;
	}

	public static void close(){
		try {
			ftp.logout();
			ftp.disconnect();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * @param args
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException {
	
	    FTPServer.setup();
	    FTPServer.upload("lab0.config", new FileInputStream(new File("lab0.config")));
	    FTPServer.close();
	}

}
